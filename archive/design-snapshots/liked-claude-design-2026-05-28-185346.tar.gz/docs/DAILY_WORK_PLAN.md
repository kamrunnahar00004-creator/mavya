# ListingLens Daily Work Plan

Status: active execution draft.

Founder constraint:

```text
14 hours per week, roughly 2 hours per day.
```

The goal is not to feel busy. The goal is to create market signal quickly.

## Daily Rule

Every work session must end with one visible artifact:

- collected photos
- written audits
- video script
- recorded video
- posted video
- working demo screen
- user message sent
- metric reviewed

No session should end with only "thinking."

## Current Phase

Phase:

```text
Validation and demo creation
```

You have already collected roughly 18 to 20 weak product photos across jewelry, candles, crochet/plush, soap, and mugs.

Immediate next milestone:

```text
Show real full-AI-polish examples, wire one improved-score preview, test five product
examples for fidelity, and turn the strongest result into demo videos.
```

## 7-Day Plan

### Day 1: Finish And Organize Samples

Expected time: 2 hours.

Tasks:

1. Create folders:

```text
samples/jewelry
samples/candles
samples/crochet-plush
samples/soap
samples/mugs
```

2. Put all collected screenshots into the right folders.
3. Rename files clearly:

```text
jewelry-01.png
candle-01.png
plush-01.png
soap-01.png
mug-01.png
```

4. Pick the best 5 examples total.
5. For each best example, write one sentence:

```text
Why this photo loses clicks:
```

Done when:

- 20 images are organized
- 5 winners are selected
- each winner has one clear problem sentence

### Day 2: Write Manual Audits

Expected time: 2 hours.

For each of the 5 winners, write:

```text
Score:
Biggest issue:
Why it hurts clicks:
Fix this first:
Thumbnail test:
```

Keep each audit short. It must fit on one screen.

Done when:

- 5 manual audits are written
- each one has a score and top 3 next steps

### Day 3: Test The Paid Transformation Outcome

Expected time: 2 hours.

The candle experiment showed that a high-quality AI-improved hero photo may be the
paid outcome sellers value. Test whether that result remains desirable and honest
across product types.

Test 5 collected photos through:

1. free audit and thumbnail proof
2. AI-improved clean hero-photo generation with simple background and better light
3. fidelity review: identify changed patterns, text, engraving, shapes, or details

Decision:

```text
Sell only the full AI-polish outcome if it is desirable and honestly labeled.
```

Do not test elaborate lifestyle scenes yet. The approved experiment is a cleaner
product hero image. Repeatable products may tolerate more generative change than
one-of-one or personalized items.

Do not build a paid light-polish tier. It is simpler and higher-trust to sell one
clear output: full AI polish with a new score reveal.

Done when:

- 5 photos have been tested
- one paid-output direction is confirmed or rejected
- fidelity risks are logged by category

### Day 4: Build Or Mock The Demo Screen

Expected time: 2 hours.

Create one screen that can be recorded.

Minimum layout:

```text
ListingLens
[photo]
Score: __/10
Thumbnail Preview
Before / After Preview
4 Pillars: Thumbnail / Lighting / Background / Click Appeal
3 Next Steps
Priority Action
```

Allowed tools:

- simple local web UI
- Canva
- Figma
- static HTML

Do not add:

- auth
- payment
- database
- dashboard
- bulk upload

Done when:

- one demo screen looks good enough for screen recording
- at least one real photo/audit is loaded into it

### Day 5: Create 5 Video Scripts

Expected time: 2 hours.

Write 5 short scripts using this structure:

```text
Hook: 0-3 seconds
Photo problem: 3-7 seconds
Score reveal: 7-10 seconds
Fix: 10-14 seconds
CTA: 14-16 seconds
```

Script examples:

```text
This Etsy photo looks fine until you see it as a thumbnail.
The product almost disappears because the background is louder than the item.
ListingLens gives it 4.2 out of 10.
Fix first: crop closer and use a calmer background.
Save this if you sell on Etsy.
```

Done when:

- 5 scripts are ready
- each script maps to one selected photo

### Day 6: Record 5 Videos

Expected time: 2 hours.

Record:

- screen recording of demo UI
- optional voiceover
- optional text overlay

Keep videos:

- 12 to 20 seconds
- one problem only
- one fix only
- no overexplaining

Done when:

- 5 draft videos exist

### Day 7: Post Or Schedule Videos

Expected time: 2 hours.

Post or schedule across:

- TikTok
- YouTube Shorts
- Instagram Reels

If you do not want to post all platforms yet, post to TikTok first.

For each video, record:

```text
hook used:
category:
posted time:
views:
likes:
comments:
saves:
DMs:
```

Done when:

- first videos are posted or scheduled
- a tracking sheet exists

### Day 8: Review Signal And Decide

Expected time: 2 hours.

Review:

- which hook got the most saves
- which category got comments
- whether sellers asked for help
- whether anyone wanted the tool

Decision:

```text
If there is signal, build V0.
If there is no signal, change hook or category before coding more.
```

Done when:

- one next-week direction is chosen

### Day 9-10: Run A Payment Test

Expected time: 2 to 4 hours total.

Do not wait until day 30 to test money.

Create one simple offer after output testing:

```text
$7.99 AI-improved hero photo
Includes one result and one regenerate.
```

Optional second offer:

```text
$19 for 5 photo audits
```

Use a Stripe Payment Link or equivalent. Fulfillment can be manual at first. The point is not automation. The point is whether sellers will pay.

Done when:

- one payment link exists
- at least 10 sellers or viewers have seen the offer
- the founder knows whether anyone attempted to pay

## If Signal Appears

Build the V0 demo app.

V0 tasks:

1. upload photo
2. category dropdown
3. AI score
4. top 3 next steps
5. thumbnail preview
6. real full-AI-polish example/proof asset with disclosure
7. original versus preview comparison
8. improved-score reveal on the AI-polished image
9. product-detail review warning
10. clean result screen for recording

Do not build the live generation/payment pipeline until the demo loop shows attention
and the generated-output fidelity test has been reviewed.

## If Signal Does Not Appear

Do not panic. Run one more test cycle.

Change only one variable:

- new hook
- new category
- new demo format
- new platform

Do not change everything at once.

## Weekly Time Budget

Use 14 hours like this:

| Area | Hours | Purpose |
|---|---:|---|
| Content | 5 | videos, scripts, hooks |
| Product | 4 | demo/app improvements |
| Research | 2 | sellers, comments, competitors |
| Outreach | 2 | DMs, Reddit, feedback |
| Review | 1 | metrics and decisions |

The product must not eat the whole week.

## 30-Day Target

By day 30:

- 30 short videos posted
- 100+ collected product-photo examples
- one working demo UI
- one waitlist or manual audit offer
- at least 10 conversations with real sellers
- at least one attempt to charge money by day 10
- one decision on whether $79 productized pack is worth testing

## 90-Day Target

By day 90:

- 100 videos posted
- V1 live if signal exists
- 1,000 free audits
- 50 paid one-shot audits
- 20 monthly subscribers
- $500 to $1,000 MRR

If these numbers are nowhere close by day 90, the correct move is not to work harder blindly. The correct move is to evaluate the niche and possibly reuse the engine for another "rate-my-X" vertical.

## Daily Shutdown Checklist

Before ending each day, write:

```text
What did I ship today?
What did I learn today?
What is the next action tomorrow?
Did I create or test distribution today?
```

If the answer to the last question is no for three days in a row, the project is drifting back into builder mode.
