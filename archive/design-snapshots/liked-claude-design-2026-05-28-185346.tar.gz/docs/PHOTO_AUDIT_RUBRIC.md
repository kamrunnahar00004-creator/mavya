# ListingLens Photo Audit Rubric

Status: active V0 rubric, revised after 10 bad-photo calibration set.

Purpose:

```text
Judge whether a product photo will earn clicks as the first image in an online listing.
```

This rubric is for ListingLens V0/V1. It must stay simple enough to fit on one screen, explain in a 15-second video, and score reliably across runs.

## Design Rules

- Visible UI shows few categories. Backend may judge more.
- One hero number, score on /10 scale.
- One priority action line.
- Three next steps max in result.
- Output must enable a Cal-AI / Umax / LooksMax style score reveal.
- Language stays blunt, short, beginner-friendly.

## Core Score

Every uploaded product photo gets:

```text
Overall Score: 0-10
```

Decimals allowed (e.g. `6.5`). Display rounds to one decimal max.

The score is the weighted sum of 4 visible pillars. The backend may judge richer sub-checks underneath those pillars, but the UI stays simple.

## Visible Pillars (shown in UI)

### 1. Thumbnail (weight 40)

Question:

```text
Can a buyer understand the product at thumbnail size?
```

Folds in: thumbnail size, centering, crop, framing, square-crop fit, product as hero, sharpness, "what is being sold" obviousness, full product visibility, label/text readability, silhouette clarity, bundle clarity, and whether the product itself is visible instead of only packaging.

Low pillar examples:

- product too small in frame
- design or label unreadable
- product cut off
- blurry product
- multiple items confuse listing
- buyer cannot tell what the product is
- packaging or label dominates the actual product
- white script or small label text disappears at mobile size
- dark product disappears into dark background
- set/bundle is unclear

### 2. Lighting (weight 25)

Question:

```text
Does the lighting make the product look clean and accurate?
```

Folds in: brightness, harsh flash, indoor yellow cast, blown highlights, lost detail, true color, color accuracy, and whether the lighting preserves product detail.

Low pillar examples:

- direct flash glare
- dark corners
- white items look gray or yellow
- shiny items lose detail
- yellow cast changes product color
- flat shadows or hard edges make the photo look rushed
- front label/product detail is underlit

### 3. Background (weight 20)

Question:

```text
Does the background support the product or fight it?
```

Folds in: background clutter, surface texture, color clash, product/background contrast, category fit, dirty surfaces, overlay graphics, and whether the setting supports buyer trust.

Low pillar examples:

- sink, floor, bed, messy table
- fabric texture louder than jewelry
- random home objects
- background ignores category norms
- stained cloth, dirty tile, or grimy grout
- light product disappears on light background
- dark product disappears on dark background
- sales badges, hearts, arrows, or text overlays crowd the hero photo
- collage/tool-template layout makes the product feel pasted together

### 4. Click Appeal (weight 15)

Question:

```text
Would a buyer stop scrolling for this image?
```

Folds in: buyer trust, premium feel, giftability, mood, color harmony, "one obvious reason to click," authenticity, and whether the image feels like a real product photo.

Low pillar examples:

- technically visible but boring
- looks like a quick snapshot
- fake AI hands, warped shapes, stretched mockup
- item does not feel worth the price
- fake-looking AI/mockup reduces trust
- cutout/composite edge makes product feel pasted in
- clean template mockup is acceptable but should be backed by real-life photo
- photo does not communicate scent, softness, use case, or giftability

## Internal Sub-Checks (backend only, not shown)

V0 uses 10 distinct checks. This is intentionally smaller than the expanded calibration list: repeated concepts are folded together so one vision call can judge them consistently.

| Sub-check | Rolls up to | Includes |
|---|---|---|
| Frame readability | Thumbnail | physical visibility only: size in frame, focus, edges, square-crop fit |
| Product recognition | Thumbnail | what it is: category identification, subject completeness, silhouette, packaging not hiding the item |
| Design and set clarity | Thumbnail | what is included: label/design legibility, bundle clarity |
| Light and detail preservation | Lighting | exposure, flash, hotspots, shadows, glare hiding detail |
| Color accuracy | Lighting | cast, true product color, controlled intentional mood |
| Setting cleanliness and distraction | Background | clutter, dirty surfaces, props, category-appropriate setting |
| Product/background separation | Background | value/color contrast, background absorbing product |
| Promotional or collage clutter | Background | text overlays, sales badges, pasted-together layout |
| Buyer desire and use clarity | Click Appeal | giftability, mood, material appeal, reason to click |
| Authenticity and trust | Click Appeal | visible AI artifacts, mockup/cutout/composite tells, real-product confidence |

Rule: visible UI never shows the sub-checks. Only the 4 pillars + overall.

### Consolidation Map

Folded without losing coverage:

| Expanded calibration checks | V0 check |
|---|---|
| Thumbnail clarity, crop and framing, product focus | Frame readability |
| Subject completeness, buyer identification, silhouette clarity, packaging dominance | Product recognition |
| Label/text contrast, bundle clarity | Design and set clarity |
| Lighting plus technical glare/highlight anchors | Light and detail preservation |
| Background, surface cleanliness, category fit | Setting cleanliness and distraction |
| Product/background contrast | Product/background separation |
| Overlay/text clutter | Promotional or collage clutter |
| Desire and click pull, buyer-trust appeal signals | Buyer desire and use clarity |
| AI/mockup authenticity, cutout/composite authenticity | Authenticity and trust |

Deferred rather than lost:

- Brand positioning belongs in later premium/pro audits, not V0.
- IP/trademark risk stays outside photo scoring.
- Component-product nuance stays category context until more examples confirm a separate need.
- Plush, soap, mug, candle, and jewelry cues stay in category notes, not extra scoring dimensions.

## Calibration Rules

Use these as scoring anchors:

- Judge as a cold buyer scrolling at thumbnail size, not as an informed reviewer.
- Centered and visible does not automatically mean strong Thumbnail if the photo communicates low trust.
- If the whole subject is cut off, hidden, too small, or visually incomplete, Thumbnail should drop.
- If the product category is unclear from the image, Thumbnail and Click Appeal should drop even when the image is clean.
- If the product and background are too similar in value or color, Background and Thumbnail should drop.
- Dirty surfaces matter more for candles, soap, skincare, food-adjacent, and gift items.
- Product identification and visible technical quality outrank mood and giftability. Attractive styling cannot earn an 8+ result when the product type is unclear or major visible flaws remain.
- With obvious low-trust AI/mockup artifacts, fake hands, warped objects, rough cutouts, or broken composites, Click Appeal cannot exceed 5. Score lower if other flaws warrant.
- With a visibly template-based but clean mockup, Click Appeal cannot exceed 6 only when the template look reduces trust. Score lower if other flaws warrant.
- Clean styling or cinematic lighting alone is not mockup evidence. Score real-looking product photos normally.
- For bundles/sets, the image must make it clear what is included.
- Do not score trademark/IP risk in V0. Keep the audit photo-only unless the founder explicitly expands scope.

For model testing, compare category-provided scoring against cold category detection. A wrong or uncertain detected category is useful calibration signal, but V0 may still accept seller-selected category as context.

## Category Notes (passed to model as context, not as a pillar)

Jewelry: shine, detail visibility, scale reference, premium feel.
Candles: label readability, container clarity, mood, scent cue, clean surface, warm lifestyle context.
Crochet/plush: softness, lint, clean background, giftability, cute factor at thumbnail size, scale, pose.
Soap: texture, cleanliness, packaging trust, scent impression, scale or use context.
Mugs: design readability, mockup trust, handle/crop clarity, giftability, bundle clarity.

Brand-positioning context is not required for V0. Save deeper brand-fit judgments for later premium/pro audits.

These adjust how Background and Click Appeal are judged. They are not a separate pillar.

## Output Format

Backend returns:

```json
{
  "overall_score": 4.2,
  "pillars": {
    "thumbnail": 3,
    "lighting": 5,
    "background": 2,
    "click_appeal": 4
  },
  "detected_category": "jewelry",
  "priority_action": "Crop closer. Product too small.",
  "next_steps": [
    { "observation": "Product too small in thumbnail.", "action": "Crop to fill 70% of square." },
    { "observation": "Background louder than product.", "action": "Shoot on plain white or cream." },
    { "observation": "Yellow indoor light killing color.", "action": "Move to window. Kill flash." }
  ],
  "share_headline": "This Etsy photo scored 4/10. Here's why.",
  "crop_suggestion": { "x": 0.12, "y": 0.08, "w": 0.76, "h": 0.76 },
  "light_adjustment": { "exposure": 0.4, "warmth": -0.2 }
}
```

Field rules:

- `overall_score`: 0-10, one decimal max.
- `pillars`: integers 0-10.
- `detected_category`: one of jewelry, candles, crochet_plush, soap, mugs, other.
- `priority_action`: imperative, <= 10 words.
- `next_steps`: exactly 3. `observation` <= 12 words. `action` <= 7 words, imperative.
- `share_headline`: pre-written TikTok caption, <= 12 words.
- `crop_suggestion`: normalized 0-1 floats for V0 thumbnail preview, or `null` for invalid inputs.
- `light_adjustment`: normalized values returned in V0 for later improved-preview/paid-unlock testing, or `null` for invalid inputs.

`crop_suggestion` and `light_adjustment` reuse the same vision call. No extra API cost.

The model returns pillar scores. The backend computes and validates `overall_score` using the locked weights, rounded to one decimal:

```text
(thumbnail * 0.40) + (lighting * 0.25) + (background * 0.20) + (click_appeal * 0.15)
```

If a model-returned overall score disagrees, the backend value wins.

## Score-Band Output Behavior

The JSON shape stays the same, but the meaning of the advice changes by score band.

### Scores 0-5

The current photo is weak. Use remediation language:

```text
priority_action: Move candle to a clean surface.
```

Fixes should tell the seller what to change or reshoot.

### Scores 6-7

The photo is usable but incomplete. Mix photo improvements and support-shot advice:

```text
priority_action: Add separate closeup photo of pendant.
```

Next steps can include one improvement to this photo and supporting photos the listing needs.

When recommending a support shot, explicitly say it is another photo. Do not write:

```text
Add filled in-hand photo.
```

Write:

```text
Add separate in-hand photo with coffee.
```

This prevents a seller from thinking a good existing photo must be changed.

### Scores 8-10

The photo is strong. Do not imply the seller should replace it.

Use "keep/add" framing:

```text
priority_action: Keep this. Add separate closeup photo.
```

For 8+ photos, `next_steps` should mostly describe missing support shots or tiny optimizations across the listing photo set:

- add separate closeup photo
- add separate flat-lay photo
- add separate scale or hand-held photo
- clarify set quantity
- add separate photo of clasp, texture, or label
- remove one small competing prop

Do not invent flaws just because the schema asks for `next_steps`. A high-scoring photo should feel affirmed.
Every support-shot action must name it as an added or separate photo. Never let it sound like an edit to the scored hero photo.

## V0 Result Card (UI mapping)

What the user sees on the result screen:

```text
[ Big number: 4.2 / 10 ]
[ Square pillar grid: Thumbnail 3, Lighting 5, Background 2, Click Appeal 4 ]
[ Low score label: "Fix this first" -> priority_action ]
[ High score label: "Keep this photo" -> priority_action ]
[ Thumbnail preview (auto-cropped per crop_suggestion) ]
[ 3 next-step cards, labels adjusted by score band ]
[ Share button ]
[ Demo CTA where prepared asset exists: "See improvement preview" ]
```

One screen. Recordable for TikTok in 6-10 seconds.

Pricing is not shown in the hardcoded recording demo. A paid improved-version CTA is
tested only after the delivered transformation is proven faithful and worth buying.

The audit remains fully useful in the free result. Payment must not hide the score,
priority action, or concrete next steps. The paid hypothesis is execution: a
separately generated `AI-improved preview` for a weak hero photo.

Do not sell a separate light-polish/crop-only tier in the initial funnel. If an
improved image is generated, score it honestly afterward and reveal the new score.

## Writing Style

Use:

- imperative actions ("Move to window. Kill flash.")
- short sentences
- beginner seller language
- specific actions
- explicit support-shot wording ("Add separate closeup photo.")

Avoid:

- "consider," "try," "you might"
- vague praise
- long paragraphs
- photography jargon
- pretending the photo can be fixed if it must be retaken
- charged labels like "dropshipping," "cheap," "scam," or "spam" unless there is clear evidence

Prefer observable wording:

- "Looks like a collage."
- "Sales text crowds the photo."
- "Background overwhelms the product."
- "Mockup look hurts buyer trust."
- "Product does not read as a candle."

Good:

```text
Product too small. Crop to fill the square.
```

Bad:

```text
Consider optimizing composition to improve visual hierarchy and increase marketplace engagement.
```

Max 7 words per action. Imperative only.

## Invalid Input Guard

Before scoring, the rubric must confirm the upload is a product photo.

If the image is a screenshot, app/IDE/document capture, meme, chat, code, selfie, or any other non-product image, return:

```json
{
  "detected_category": "other",
  "overall_score": 0.0,
  "pillars": { "thumbnail": 0, "lighting": 0, "background": 0, "click_appeal": 0 },
  "priority_action": "Upload a product photo.",
  "next_steps": [
    { "observation": "This is not a product photo.", "action": "Upload product photo." },
    { "observation": "No product is visible.", "action": "Show item being sold." },
    { "observation": "Audit cannot judge listing.", "action": "Use original product image." }
  ],
  "share_headline": "Upload a product photo to get scored.",
  "crop_suggestion": null,
  "light_adjustment": null
}
```

Rule: do not try to fit non-products into the rubric. Reject cleanly with structured output, not a freeform error.

## Out Of Scope For V0

Not in rubric, not in result card, not in prompt:

- full lifestyle scene generation
- model/face/hand generation
- multi-image listing analysis
- SEO text / title / tags
- competitor benchmarking
- trademark/IP risk scoring
- brand-positioning audit

AI-generated clean hero-photo previews are a separate output-generation feature, not
part of scoring. They may include a simplified background after fidelity testing and
must tell sellers to review product details before publishing. Lifestyle scenes remain
V2/pro scope.

## Phase Fit

This rubric serves validation/demo phase:

- 4 visible pillars = TikTok-readable result card
- /10 score = LooksMax-style "You're a 7" hook
- pre-written `share_headline` = creator-friendly distribution
- `crop_suggestion` + `light_adjustment` = data returned in V0 for improved-preview and later paid-unlock testing without extra API cost

If the vision model proves unreliable at 4-pillar scoring on collected sample photos, reduce visible pillars to 3 (Thumbnail, Lighting, Background) and fold Click Appeal into overall score only.
