"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AppHeader } from "@/components/app-header";
import { UploadWorkspace } from "@/components/upload-workspace";
import { AnalyzingState } from "@/components/analyzing-state";
import { AuditWorkspace } from "@/components/audit-workspace";
import { InvalidUploadState } from "@/components/invalid-upload-state";
import {
  DEMO_STATES,
  VERIFY_AMBER_DEMO,
  type DemoStateId,
} from "@/data/demo-states";
import { prefersReducedMotion } from "@/lib/utils";

type Mode = "upload" | "analyzing" | DemoStateId | "verify";

const VALID_QUERY_STATES: Mode[] = [
  "upload",
  "analyzing",
  "weak",
  "strong",
  "invalid",
  "verify",
];

const KEY_MAP: Record<string, Mode> = {
  "1": "upload",
  "2": "weak",
  "3": "strong",
  "4": "invalid",
  "5": "verify",
};

export default function Page() {
  const [mode, setMode] = useState<Mode>("upload");
  const [staticRender, setStaticRender] = useState(false);
  const [initialPreview, setInitialPreview] = useState(false);
  const [uploadedUrl, setUploadedUrl] = useState<string | undefined>(undefined);
  const uploadedUrlRef = useRef<string | undefined>(undefined);

  // Hidden demo route: ?state=weak|strong|invalid|analyzing|upload|verify
  // Verify route renders synthetic amber 7.0 gauge for screenshot validation.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    const q = params.get("state") as Mode | null;
    const shouldRenderStatic = params.get("static") === "1";
    const shouldOpenPreview = params.get("preview") === "1";
    if ((q && VALID_QUERY_STATES.includes(q)) || shouldRenderStatic) {
      const id = window.setTimeout(() => {
        if (q && VALID_QUERY_STATES.includes(q)) setMode(q);
        setStaticRender(shouldRenderStatic);
        setInitialPreview(shouldOpenPreview);
      }, 0);
      return () => window.clearTimeout(id);
    }
  }, []);

  // Hidden keyboard route for fast state switching during recording.
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) {
        return;
      }
      const next = KEY_MAP[e.key];
      if (next) {
        e.preventDefault();
        setMode(next);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Revoke any blob URL when replaced.
  useEffect(() => {
    return () => {
      if (uploadedUrlRef.current) {
        URL.revokeObjectURL(uploadedUrlRef.current);
      }
    };
  }, []);

  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) {
      setMode("invalid");
      return;
    }
    if (uploadedUrlRef.current) {
      URL.revokeObjectURL(uploadedUrlRef.current);
    }
    const url = URL.createObjectURL(file);
    uploadedUrlRef.current = url;
    setUploadedUrl(url);
    setMode("analyzing");
    const wait = prefersReducedMotion() ? 200 : 1400;
    window.setTimeout(() => setMode("weak"), wait);
  }, []);

  const reset = useCallback(() => {
    if (uploadedUrlRef.current) {
      URL.revokeObjectURL(uploadedUrlRef.current);
      uploadedUrlRef.current = undefined;
    }
    setUploadedUrl(undefined);
    setMode("upload");
  }, []);

  const showNewAudit =
    mode === "weak" ||
    mode === "strong" ||
    mode === "invalid" ||
    mode === "verify";

  return (
    <>
      <AppHeader showNewAudit={showNewAudit} onNewAudit={reset} />

      {mode === "upload" && <UploadWorkspace onFile={handleFile} />}

      {mode === "analyzing" && (
        <AnalyzingState
          imageSrc={uploadedUrl ?? DEMO_STATES.weak.imageSrc}
          imageAlt={DEMO_STATES.weak.imageAlt}
        />
      )}

      {mode === "weak" && (
        <AuditWorkspace
          state={DEMO_STATES.weak}
          uploadedSrc={uploadedUrl}
          animate={!staticRender}
          initialPreview={initialPreview}
          onCta={() => undefined}
        />
      )}

      {mode === "strong" && (
        <AuditWorkspace
          state={DEMO_STATES.strong}
          animate={!staticRender}
          onCta={reset}
        />
      )}

      {mode === "verify" && (
        <AuditWorkspace
          state={VERIFY_AMBER_DEMO}
          animate={!staticRender}
          onCta={reset}
        />
      )}

      {mode === "invalid" && <InvalidUploadState onTryAgain={reset} />}
    </>
  );
}
