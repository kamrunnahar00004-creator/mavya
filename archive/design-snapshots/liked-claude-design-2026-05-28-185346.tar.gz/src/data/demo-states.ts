/**
 * Hardcoded calibrated demo state data for V0.
 * Sources locked from docs/CALIBRATION_LOG.md.
 *
 * When real API connects later, this file gets replaced by a fetched response
 * matching the same shape (see docs/PHOTO_AUDIT_PROMPT_V0.md output schema).
 */

export type PillarKey = "thumbnail" | "lighting" | "background" | "click_appeal";

export type Pillar = {
  key: PillarKey;
  label: string;
  value: number;
};

export type NextStep = {
  observation: string;
  action: string;
};

export type DemoBand = "weak" | "mid" | "strong";

export type DemoState = {
  id: "weak" | "strong" | "invalid";
  band: DemoBand | "invalid";
  overallScore: number;
  verdict: string;
  priorityLabel: string;
  priorityAction: string;
  priorityObservation?: string;
  pillars: Pillar[];
  nextStepsLabel: string;
  nextSteps: NextStep[];
  ctaLabel: string;
  /** image path under public/ */
  imageSrc: string;
  imageAlt: string;
  /** optional AI-improved preview image path under public/ */
  improvedSrc?: string;
  /** comparison rendering: slider when before/after aligned, toggle when reframed */
  comparisonMode?: "slider" | "toggle";
  /** scored result for the AI-improved preview (rescored by backend in production) */
  improvedScore?: number;
  /** verdict shown for the improved preview */
  improvedVerdict?: string;
  /** photo-specific copy for the marketplace thumbnail proof module */
  thumbnailHeadline: string;
  thumbnailSub: string;
};

export const WEAK_DEMO: DemoState = {
  id: "weak",
  band: "weak",
  overallScore: 4.1,
  verdict: "Your hero photo needs work",
  priorityLabel: "Fix This First",
  priorityAction: "Retake without flash in soft daylight.",
  priorityObservation: "Flash glare is hiding the candle detail.",
  pillars: [
    { key: "thumbnail", label: "Thumbnail", value: 5 },
    { key: "lighting", label: "Lighting", value: 3 },
    { key: "background", label: "Background", value: 4 },
    { key: "click_appeal", label: "Click Appeal", value: 4 },
  ],
  nextStepsLabel: "Also improve",
  nextSteps: [
    {
      observation:
        "Flash is bouncing off the cup and wax, hiding the handmade detail. Reshoot beside a window with flash off and light coming from the side.",
      action: "Retake in soft daylight.",
    },
    {
      observation:
        "The hearts and wax surface look rough in this close crop. Use the cleanest finished candle as the hero image so the product feels gift-ready.",
      action: "Show cleaner finished candle.",
    },
    {
      observation:
        "The roses and leaves pull attention away from the candle. Use a plain cream, white, or soft neutral background so the product is the hero.",
      action: "Use simpler plain background.",
    },
  ],
  ctaLabel: "Create improved hero photo",
  imageSrc: "/assets/candle-02.png",
  imageAlt: "Pink teacup candle with heart-shaped wax decorations",
  improvedSrc: "/assets/candle-02-improved.png",
  comparisonMode: "toggle",
  improvedScore: 8.2,
  improvedVerdict: "Strong hero photo",
  thumbnailHeadline: "This is what buyers see in Etsy search.",
  thumbnailSub: "At this size, glare hides the candle detail.",
};

export const STRONG_DEMO: DemoState = {
  id: "strong",
  band: "strong",
  overallScore: 8.2,
  verdict: "Strong hero photo",
  priorityLabel: "Keep This Photo",
  priorityAction: "Keep this. Add separate product-only photo.",
  pillars: [
    { key: "thumbnail", label: "Thumbnail", value: 8 },
    { key: "lighting", label: "Lighting", value: 9 },
    { key: "background", label: "Background", value: 9 },
    { key: "click_appeal", label: "Click Appeal", value: 7 },
  ],
  nextStepsLabel: "Add next",
  nextSteps: [
    {
      observation: "Multiple earrings make listing contents unclear.",
      action: "Add separate included-pieces photo.",
    },
    {
      observation: "Initial stud detail is small.",
      action: "Add separate macro detail photo.",
    },
    {
      observation: "Size reads naturally but not precisely.",
      action: "Add separate measurement photo.",
    },
  ],
  ctaLabel: "Score another photo",
  imageSrc: "/assets/earring-strong.jpg",
  imageAlt: "Model wearing initial stud earrings",
  thumbnailHeadline: "This is what buyers see in Etsy search.",
  thumbnailSub: "The earrings remain clear at thumbnail size.",
};

export const INVALID_DEMO: DemoState = {
  id: "invalid",
  band: "invalid",
  overallScore: 0,
  verdict: "Not a product photo",
  priorityLabel: "",
  priorityAction:
    "ListingLens scores listing photos, not screenshots or documents.",
  pillars: [],
  nextStepsLabel: "",
  nextSteps: [],
  ctaLabel: "Try another upload",
  imageSrc: "/assets/invalid-screenshot.png",
  imageAlt: "Submitted non-product file",
  thumbnailHeadline: "",
  thumbnailSub: "",
};

/**
 * Verification-only synthetic state for screenshotting the amber gauge band.
 * Not part of the user-facing demo flow.
 * Reachable via ?state=verify (or temporary keyboard shortcut).
 */
export const VERIFY_AMBER_DEMO: DemoState = {
  id: "weak", // verification state reuses a demo-state identifier only
  band: "mid",
  overallScore: 7.0,
  verdict: "Almost there",
  priorityLabel: "Improve This",
  priorityAction: "Brighten label area or angle for clarity.",
  priorityObservation: "Small details should read without zooming.",
  pillars: [
    { key: "thumbnail", label: "Thumbnail", value: 7 },
    { key: "lighting", label: "Lighting", value: 6 },
    { key: "background", label: "Background", value: 7 },
    { key: "click_appeal", label: "Click Appeal", value: 7 },
  ],
  nextStepsLabel: "Next steps",
  nextSteps: [
    {
      observation: "Synthetic verification state.",
      action: "Sharpen photo composition.",
    },
    {
      observation: "Verification copy two.",
      action: "Add separate detail photo.",
    },
    {
      observation: "Verification copy three.",
      action: "Improve lighting balance.",
    },
  ],
  ctaLabel: "Score another photo",
  imageSrc: "/assets/candle-02.png",
  imageAlt: "Verification placeholder",
  thumbnailHeadline: "Verification state.",
  thumbnailSub: "Synthetic 7.0 amber gauge sample.",
};

export type DemoStateId = DemoState["id"];

export const DEMO_STATES: Record<DemoStateId, DemoState> = {
  weak: WEAK_DEMO,
  strong: STRONG_DEMO,
  invalid: INVALID_DEMO,
};
