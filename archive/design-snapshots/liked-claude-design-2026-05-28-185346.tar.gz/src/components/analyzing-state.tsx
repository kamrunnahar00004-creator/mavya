"use client";

import Image from "next/image";

type Props = {
  imageSrc?: string;
  imageAlt?: string;
};

export function AnalyzingState({ imageSrc, imageAlt = "" }: Props) {
  return (
    <main className="px-6 py-10 pb-24">
      <div className="mx-auto grid max-w-[1200px] grid-cols-[1.05fr_1fr] gap-10 items-start">
        {/* Left: submitted photo */}
        <section aria-label="Submitted photo">
          <div className="overflow-hidden rounded-[var(--radius-xl)] border border-[var(--color-border-soft)] bg-[var(--color-surface)] shadow-[var(--shadow-soft)]">
            <div className="relative h-[clamp(430px,calc(100vh-300px),580px)] w-full bg-[var(--color-page-deep)]">
              {imageSrc ? (
                <Image
                  src={imageSrc}
                  alt={imageAlt}
                  fill
                  className="object-contain"
                  sizes="(max-width: 1280px) 540px, 580px"
                  priority
                  unoptimized={imageSrc.startsWith("blob:")}
                />
              ) : (
                <div
                  className="h-full w-full"
                  style={{
                    background:
                      "linear-gradient(135deg, #F5EFE7 0%, #E8DECF 100%)",
                  }}
                />
              )}
            </div>
          </div>
        </section>

        {/* Right: skeleton */}
        <section
          aria-label="Analyzing photo"
          aria-live="polite"
          className="flex flex-col gap-8 pt-1"
        >
          <div className="flex items-center gap-2">
            <span
              aria-hidden="true"
              className="inline-block h-1.5 w-6 rounded-full bg-[var(--color-primary)] animate-pulse"
            />
            <span className="eyebrow">Analyzing photo</span>
          </div>

          <div className="flex flex-col gap-4">
            <div className="skeleton-shimmer h-[88px] w-[200px] rounded-[var(--radius-lg)]" />
            <div className="skeleton-shimmer h-6 w-[160px] rounded-full" />
          </div>

          <div className="skeleton-shimmer h-[68px] w-full rounded-[var(--radius-xl)]" />

          <div className="hairline" />

          <div className="grid grid-cols-2 gap-x-8 gap-y-5">
            <SkeletonPillar />
            <SkeletonPillar />
            <SkeletonPillar />
            <SkeletonPillar />
          </div>

          <div className="hairline" />

          <div className="flex flex-col gap-4">
            <div className="skeleton-shimmer h-5 w-[80px] rounded-full" />
            <div className="skeleton-shimmer h-12 w-full rounded-md" />
            <div className="skeleton-shimmer h-12 w-full rounded-md" />
            <div className="skeleton-shimmer h-12 w-full rounded-md" />
          </div>
        </section>
      </div>
    </main>
  );
}

function SkeletonPillar() {
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-baseline justify-between">
        <div className="skeleton-shimmer h-3 w-[60px] rounded-full" />
        <div className="skeleton-shimmer h-6 w-[40px] rounded-md" />
      </div>
      <div className="skeleton-shimmer h-1.5 w-full rounded-full" />
    </div>
  );
}
