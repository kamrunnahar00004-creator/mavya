"use client";

import { useEffect, useState } from "react";
import {
  Wrench,
  Sparkles,
  ArrowRight,
  WandSparkles,
  CheckCircle2,
} from "lucide-react";
import type { DemoState } from "@/data/demo-states";
import {
  bandColors,
  bandForScore,
  cn,
  prefersReducedMotion,
  type ScoreBand,
} from "@/lib/utils";
import { MediaProofPanel } from "./media-proof-panel";
import { MarketplaceThumbnailPreview } from "./marketplace-thumbnail-preview";
import { ComparisonPreview } from "./comparison-preview";
import { ScoreVerdict } from "./score-verdict";
import { PillarScores } from "./pillar-scores";
import { NextSteps } from "./next-steps";

type Props = {
  state: DemoState;
  uploadedSrc?: string;
  onCta: () => void;
  animate?: boolean;
  initialPreview?: boolean;
};

export function AuditWorkspace({
  state,
  uploadedSrc,
  onCta,
  animate = true,
  initialPreview = false,
}: Props) {
  const [revealed, setRevealed] = useState(!animate);
  const [activeTab, setActiveTab] = useState<"original" | "preview">(
    initialPreview ? "preview" : "original"
  );
  const [previewUnlocked, setPreviewUnlocked] = useState(initialPreview);
  const [hasImprovement, setHasImprovement] = useState(false);

  useEffect(() => {
    if (!animate) return;
    const delay = prefersReducedMotion() ? 16 : 40;
    const id = window.setTimeout(() => setRevealed(true), delay);
    return () => window.clearTimeout(id);
  }, [animate]);

  const isWeak = state.band === "weak";
  const isMid = state.band === "mid";
  const isStrong = state.band === "strong";
  const canShowImprovement = isWeak || isMid;
  const improvedSrc = state.improvedSrc;
  const previewActive =
    canShowImprovement &&
    hasImprovement &&
    previewUnlocked &&
    activeTab === "preview";

  const displayScore =
    previewActive && state.improvedScore !== undefined
      ? state.improvedScore
      : state.overallScore;
  const displayVerdict =
    previewActive && state.improvedVerdict
      ? state.improvedVerdict
      : state.verdict;
  const scoreDeltaLabel =
    previewActive && state.improvedScore !== undefined
      ? `${state.overallScore.toFixed(1)} -> ${state.improvedScore.toFixed(1)}`
      : "";

  useEffect(() => {
    if (!canShowImprovement || !improvedSrc) return;
    let cancelled = false;
    const probe = new window.Image();
    probe.onload = () => !cancelled && setHasImprovement(true);
    probe.onerror = () => {
      if (!cancelled) {
        setHasImprovement(false);
        setActiveTab("original");
      }
    };
    probe.src = improvedSrc;
    return () => {
      cancelled = true;
    };
  }, [canShowImprovement, improvedSrc]);

  return (
    <main className="px-6 py-5 pb-10">
      <div
        className={cn(
          "mx-auto grid max-w-[1200px] grid-cols-[1.05fr_1fr] gap-8 items-start",
          revealed && "reveal-on"
        )}
      >
        {/* LEFT: MEDIA */}
        <section
          aria-label="Submitted photo and previews"
          className="flex flex-col gap-4"
        >
          <MediaProofPanel
            src={state.imageSrc}
            overrideSrc={
              activeTab === "preview" && hasImprovement && improvedSrc
                ? improvedSrc
                : uploadedSrc
            }
            alt={state.imageAlt}
            placeholderLabel={state.imageSrc.split("/").pop()}
            placeholderSub={
              isStrong
                ? "model-worn initial earring (strong demo)"
                : isWeak
                ? "teacup candle (weak demo)"
                : undefined
            }
            contain
          />

          {canShowImprovement && hasImprovement && improvedSrc && previewUnlocked && (
            <ComparisonPreview
              improvedSrc={improvedSrc}
              mode={state.comparisonMode}
              activeTab={activeTab}
              onTabChange={setActiveTab}
            />
          )}

          <MarketplaceThumbnailPreview
            src={state.imageSrc}
            overrideSrc={
              previewActive && improvedSrc ? improvedSrc : uploadedSrc
            }
            alt=""
            headline={
              previewActive
                ? "This is how the improved photo appears in search."
                : state.thumbnailHeadline
            }
            sub={
              previewActive
                ? "Cleaner background keeps the candle readable."
                : state.thumbnailSub
            }
            contain={previewActive}
          />
        </section>

        {/* RIGHT: AUDIT */}
        <section
          aria-label="Audit result"
          className="flex flex-col gap-3.5"
        >
          <div className="reveal-item" data-reveal-order="0">
            <ScoreVerdict
              key={previewActive ? "improved" : "original"}
              score={displayScore}
              verdict={displayVerdict}
              animate={animate}
            />
            {previewActive && (
              <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12.5px]">
                <span className="inline-flex items-center gap-1.5 font-semibold text-[var(--color-ink-muted)]">
                  <span className="text-[var(--color-weak)]">
                    {state.overallScore.toFixed(1)}
                  </span>
                  <ArrowRight className="h-3 w-3 text-[var(--color-ink-soft)]" aria-hidden="true" />
                  <span className="text-[var(--color-strong)]">
                    {state.improvedScore?.toFixed(1)}
                  </span>
                </span>
                <span className="text-[var(--color-ink-soft)]">
                  Re-scored after generation.
                </span>
              </div>
            )}
          </div>

          {previewActive ? (
            <div className="reveal-item" data-reveal-order="1">
              <ImprovedPreviewPanel scoreDeltaLabel={scoreDeltaLabel} />
              <div className="mt-4">
                <PrimaryButton onClick={onCta} variant="primary">
                  Do another photo
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </PrimaryButton>
              </div>
            </div>
          ) : (
            <>
              <div className="reveal-item" data-reveal-order="1">
                <PriorityBlock
                  label={state.priorityLabel}
                  action={state.priorityAction}
                  observation={state.priorityObservation}
                  score={state.overallScore}
                  band={bandForScore(state.overallScore)}
                />
              </div>

              <div className="reveal-item" data-reveal-order="2">
                <PillarScores pillars={state.pillars} />
              </div>

              <div className="reveal-item" data-reveal-order="3">
                <NextSteps
                  label={state.nextStepsLabel}
                  steps={state.nextSteps}
                  band={bandForScore(state.overallScore)}
                />
              </div>

              <div className="reveal-item mt-1.5 border-t border-[var(--color-border-soft)] pt-4" data-reveal-order="4">
                {isStrong && (
                  <PrimaryButton onClick={onCta} variant="primary">
                    {state.ctaLabel}
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </PrimaryButton>
                )}
                {canShowImprovement &&
                  hasImprovement &&
                  activeTab === "original" && (
                    <PrimaryButton
                      onClick={() => {
                        setPreviewUnlocked(true);
                        setActiveTab("preview");
                        onCta();
                      }}
                      variant="primary"
                    >
                      <WandSparkles className="h-4 w-4" aria-hidden="true" />
                      {state.ctaLabel}
                    </PrimaryButton>
                  )}
              </div>
            </>
          )}
        </section>
      </div>
    </main>
  );
}

function ImprovedPreviewPanel({ scoreDeltaLabel }: { scoreDeltaLabel: string }) {
  const items = [
    "Cleaner product-first background.",
    "Softer light on the candle.",
    "Clearer search thumbnail.",
  ];

  return (
    <div className="rounded-[var(--radius-xl)] border border-[var(--color-border-soft)] bg-white px-5 py-4 shadow-[var(--shadow-soft)]">
      <div className="flex items-start gap-3">
        <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-[var(--color-strong-soft)] text-[var(--color-strong)]">
          <WandSparkles className="h-4 w-4" aria-hidden="true" />
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-[0.14em] text-[var(--color-strong)]">
            AI-improved preview
          </div>
          <p className="mt-1 text-[18px] font-bold leading-[1.25] text-[var(--color-ink)]">
            The hero photo now reads clean at a glance.
          </p>
          <p className="mt-1 text-[12.5px] leading-snug text-[var(--color-ink-muted)]">
            ListingLens scored this generated image again after the hero photo
            was improved.
          </p>
        </div>
      </div>

      {scoreDeltaLabel && (
        <div className="mt-4 inline-flex rounded-full bg-[var(--color-strong-soft)] px-3 py-1 text-[13px] font-bold text-[var(--color-strong)]">
          {scoreDeltaLabel}
        </div>
      )}

      <ul className="mt-4 grid gap-2">
        {items.map((item) => (
          <li
            key={item}
            className="flex items-center gap-2 rounded-[var(--radius-md)] bg-[var(--color-page)] px-3 py-2 text-[13.5px] font-semibold text-[var(--color-ink)]"
          >
            <CheckCircle2
              className="h-4 w-4 flex-shrink-0 text-[var(--color-strong)]"
              aria-hidden="true"
            />
            {item}
          </li>
        ))}
      </ul>

      <p className="mt-3 text-[12.5px] leading-snug text-[var(--color-ink-muted)]">
        Review product details before publishing. Original audit is available
        when you switch back to Original.
      </p>
    </div>
  );
}

function PriorityBlock({
  label,
  action,
  observation,
  score,
  band,
}: {
  label: string;
  action: string;
  observation?: string;
  score: number;
  band: ScoreBand;
}) {
  const Icon = band === "strong" ? Sparkles : Wrench;
  // Priority block color follows the SCORE BAND, not just weak/strong split
  const scoreBand = bandForScore(score);
  const colors = bandColors(scoreBand);

  return (
    <div
      className="relative rounded-[var(--radius-xl)] px-5 py-3"
      style={{ background: colors.soft }}
    >
      <div className="flex items-start gap-3">
        <div
          className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-white shadow-[0_1px_2px_rgba(25,23,20,0.06)]"
          style={{ color: colors.accent }}
        >
          <Icon className="h-4 w-4" strokeWidth={2} aria-hidden="true" />
        </div>
        <div className="flex-1">
          <div
            className="text-[10px] font-bold uppercase tracking-[0.14em]"
            style={{ color: colors.accent }}
          >
            {label}
          </div>
          <div className="mt-0.5 text-[18px] font-bold leading-[1.25] tracking-[-0.005em] text-[var(--color-ink)]">
            {action}
          </div>
          {observation && (
            <div className="mt-1 text-[13px] leading-snug text-[var(--color-ink-muted)]">
              {observation}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function PrimaryButton({
  onClick,
  variant,
  children,
}: {
  onClick: () => void;
  variant: "primary" | "neutral";
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-2 rounded-full px-6 py-3 text-[15px] font-semibold text-white transition-all active:translate-y-[1px]",
        variant === "primary"
          ? "bg-[var(--color-primary)] shadow-[0_4px_12px_rgba(232,107,57,0.30)] hover:bg-[var(--color-primary-hover)] hover:shadow-[0_6px_16px_rgba(216,91,44,0.36)]"
          : "bg-[var(--color-neutral-dark)] shadow-[0_4px_12px_rgba(63,58,53,0.25)] hover:bg-[var(--color-neutral-dark-hover)]"
      )}
    >
      {children}
    </button>
  );
}
