"use client";

import { useRef, useState, type DragEvent, type KeyboardEvent } from "react";
import Image from "next/image";
import { ImageUp, ArrowRight, WandSparkles } from "lucide-react";
import { cn } from "@/lib/utils";

type Props = {
  onFile: (file: File) => void;
};

export function UploadWorkspace({ onFile }: Props) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [dragActive, setDragActive] = useState(false);

  function openPicker() {
    inputRef.current?.click();
  }

  function handleKey(e: KeyboardEvent<HTMLDivElement>) {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      openPicker();
    }
  }

  return (
    <main className="px-6 pt-14 pb-16">
      <div className="mx-auto max-w-[860px] text-center">
        <h1 className="font-display text-[48px] font-bold tracking-[-0.02em] leading-[1.04] text-[var(--color-ink)]">
          Rate your Etsy first photo.
        </h1>
        <p className="mx-auto mt-5 max-w-[520px] text-[17px] leading-relaxed text-[var(--color-ink-muted)]">
          See what is costing your listing clicks.
        </p>

        <div
          role="button"
          tabIndex={0}
          aria-label="Upload product photo"
          onClick={openPicker}
          onKeyDown={handleKey}
          onDragOver={(e: DragEvent<HTMLDivElement>) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={(e: DragEvent<HTMLDivElement>) => {
            e.preventDefault();
            setDragActive(false);
            const file = e.dataTransfer.files?.[0];
            if (file && file.type.startsWith("image/")) onFile(file);
          }}
          className={cn(
            "group mx-auto mt-10 flex h-[320px] w-full max-w-[720px] cursor-pointer flex-col items-center justify-center gap-5 rounded-[var(--radius-2xl)] border border-[var(--color-border)] bg-white px-6 py-8 transition-all",
            "shadow-[var(--shadow-soft)]",
            "hover:border-[var(--color-primary)] hover:shadow-[var(--shadow-soft-strong)]",
            dragActive && "dropzone-active"
          )}
        >
          <div className="flex h-16 w-16 items-center justify-center rounded-[var(--radius-xl)] bg-[var(--color-tint)] text-[var(--color-primary)] ring-1 ring-inset ring-[var(--color-tint-deep)]">
            <ImageUp className="h-7 w-7" strokeWidth={1.8} aria-hidden="true" />
          </div>

          <div className="text-center">
            <div className="text-[17px] font-semibold text-[var(--color-ink)]">
              Drop your first listing photo
            </div>
            <div className="mt-1 text-[13px] text-[var(--color-ink-muted)]">
              PNG or JPG, one hero image
            </div>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              openPicker();
            }}
            className={cn(
              "rounded-full bg-[var(--color-primary)] px-7 py-3 text-[15px] font-semibold text-white shadow-[0_4px_12px_rgba(232,107,57,0.30)]",
              "transition-all hover:bg-[var(--color-primary-hover)] hover:shadow-[0_6px_16px_rgba(216,91,44,0.36)] active:translate-y-[1px]"
            )}
          >
            Upload photo
          </button>

          <input
            ref={inputRef}
            type="file"
            accept="image/png,image/jpeg"
            hidden
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onFile(file);
            }}
          />
        </div>

        <p className="mt-5 text-[13px] text-[var(--color-ink-muted)]">
          First rating free. No signup.
        </p>

        <ExampleProof />
      </div>
    </main>
  );
}

function ExampleProof() {
  return (
    <div className="mx-auto mt-12 w-fit max-w-[560px] rounded-[var(--radius-xl)] border border-[var(--color-border-soft)] bg-white px-5 py-4 shadow-[var(--shadow-soft)]">
      <div className="mb-3 flex items-center justify-center gap-1.5">
        <WandSparkles
          className="h-3.5 w-3.5 text-[var(--color-primary)]"
          aria-hidden="true"
        />
        <span className="eyebrow">Example: full AI polish</span>
      </div>
      <div className="flex items-center gap-4">
        <ProofTile src="/assets/candle-02.png" badge="4.1" tone="weak" />
        <ArrowRight
          className="h-5 w-5 flex-shrink-0 text-[var(--color-ink-soft)]"
          aria-hidden="true"
        />
        <ProofTile src="/assets/candle-02-improved.png" badge="8.2" tone="strong" />
      </div>
    </div>
  );
}

function ProofTile({
  src,
  badge,
  tone,
}: {
  src: string;
  badge: string;
  tone: "weak" | "strong";
}) {
  const color =
    tone === "weak" ? "var(--color-weak)" : "var(--color-strong)";
  return (
    <div className="relative h-[112px] w-[112px] overflow-hidden rounded-[var(--radius-md)] border border-[var(--color-border)] bg-[var(--color-page-deep)]">
      <Image
        src={src}
        alt=""
        fill
        className="object-contain"
        sizes="112px"
      />
      <span
        className="absolute bottom-1.5 left-1.5 rounded-full px-2 py-0.5 text-[11px] font-bold text-white"
        style={{ background: color }}
      >
        {badge}
      </span>
    </div>
  );
}
