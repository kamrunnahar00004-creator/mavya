# ListingLens public/assets

Real product photos served by Next.js Image at `/assets/*`.

## Required Files

| File | Status | Purpose |
|---|---|---|
| `candle-02.png` | **Present** | Weak result demo (gold score 4.1) |
| `earring-strong.jpg` | **Missing** | Strong result demo (gold score 8.2) — model-worn initial earring |
| `invalid-screenshot.png` | **Missing** | Invalid input demo |
| `candle-02-improved.png` | **Present** | AI-improved hero preview for candle-02 |

## Behavior When Asset Missing

- The main media panel and marketplace thumbnail show a labeled placeholder tile (warm gradient + filename).
- `Create improved hero photo` CTA and the Original/AI-improved comparison toggle render only when `candle-02-improved.png` exists.

## Image Specs

- Square aspect ratio preferred (1:1).
- ≥ 1200×1200px for sharp display on Retina.
- PNG or JPG.
