# Generated Preview Candidates

These files are validation candidates, not automatically published app assets.

## candle-02-ai-hero-preview-v1.png

Source image:

```text
public/assets/candle-02.png
```

Created:

```text
2026-05-27 through Codex built-in image_gen editing
```

Purpose:

```text
Test whether an AI-improved clean hero photo is valuable enough to become the paid ListingLens outcome.
```

Assessment:

- Strong visual transformation and clear paid-value signal.
- Preserves the recognizability of the teacup candle.
- May regenerate micro-details in the china pattern, pearls, or wax surface.

Usage rule:

- Do not display this image in the app as a plain corrected original.
- When wired into the preview state, label it `AI-improved preview`.
- Display `Review product details before publishing.`
- Keep the original visible for comparison.

